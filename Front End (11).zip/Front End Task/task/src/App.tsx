import React, { useState } from 'react';
import "./App.css";
import moment from 'moment';



function App() {
  // Declare a new state variable, which we'll call "count"
  const [state, setState] = useState<State>({lastClicked:undefined,buttonColor:"red"});


  function updateState(){
    setState(perevstate => ({
    ...perevstate,
    lastClicked:new Date(),
    buttonColor:(perevstate?.buttonColor=="red"?"blue":perevstate?.buttonColor=="blue"?"green":perevstate?.buttonColor=="green"?"red":"red")
  }))
};

  return (
    <div>
    <div>
    <button
      onClick={updateState}
      style={{ backgroundColor: state.buttonColor }}
    >
      Click
    </button>
  </div>
  <div className="TimeContainer">
    <div className="TimeItem">
      Local time:{" "}
      {state.lastClicked !== undefined ? moment(state.lastClicked.toString()).format('LLL') : "Never"}
    </div>
    <div className="TimeItem">
      GMT Time:{" "}
      {state.lastClicked !== undefined ? moment.utc(state.lastClicked).format('LLL'): "Never"}
    </div>
    <div className="TimeItem">
      ACT Time:{" "}
      {state.lastClicked !== undefined ?  moment.utc(state.lastClicked).utcOffset(570).format('LLL'): "Never"}
    </div>
  </div>
  </div>
  );
}


interface State {
  lastClicked?: Date;
  buttonColor: "red" | "blue" | "green";
}

// class App extends React.Component<object, State> {
//   constructor(props: object) {
//     super(props);
//     this.state = {
//       lastClicked: undefined,
//       buttonColor: "red",
//     };
//   }

//   public render() {
//     const { lastClicked, buttonColor } = this.state;

//     return (
//       <>
//         <div>
//           <button
//             onClick={this.onClick}
//             style={{ backgroundColor: buttonColor }}
//           >
//             Click
//           </button>
//         </div>
//         <div className="TimeContainer">
//           <div className="TimeItem">
//             Local time:{" "}
//             {lastClicked !== undefined ? lastClicked.toString() : "Never"}
//           </div>
//           <div className="TimeItem">
//             GMT Time:{" "}
//             {lastClicked !== undefined ? lastClicked.toString() : "Never"}
//           </div>
//           <div className="TimeItem">
//             ACT Time:{" "}
//             {lastClicked !== undefined ? lastClicked.toString() : "Never"}
//           </div>
//         </div>
//       </>
//     );
//   }

//   private onClick = () => {
//     this.setState({
//       lastClicked: new Date(),
//       buttonColor: this.getNextButtonColor(),
//     });
//   };

//   private getNextButtonColor = (): "red" | "blue" | "green" => {
//     switch (this.state.buttonColor) {
//       case "red":
//         return "blue";
//       case "blue":
//         return "green";
//       case "green":
//         return "red";
//       default:
//         throw new Error("Invalid color");
//     }
//   };
// }

export default App;
